<?php 
/**
 * Template Name: Right Sidebar
 */
global $global_page_layout;
$global_page_layout = 'right';
get_template_part( 'page' );