<?php 
/*
 * Template Name: Front Page
 */
get_template_part( 'page' );