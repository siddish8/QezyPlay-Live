<?php 
/**
 * Template Name: Left Sidebar
 */
global $global_page_layout;
$global_page_layout = 'left';
get_template_part( 'page' );