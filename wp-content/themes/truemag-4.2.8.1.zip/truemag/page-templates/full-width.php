<?php
/**
 * Template Name: Full Width (no-sidebar)
 */
global $global_page_layout;
$global_page_layout = 'full';
get_template_part( 'page' );
