<?php
echo do_shortcode('[tm_amazing]');
?>
