<?php
/* Include custom widgets file here
 *
 * Should be placed in \inc\widgets\ folder
 */
include('shortcode/cat-videos.php');
include('shortcode/related-format.php');
?>