<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cameron
 */
interface EmbedConfigInterface {

  public function getConfig();

  public function generateDiv();

  public function getId();

  public function generateEmbedScript();

}
?>
