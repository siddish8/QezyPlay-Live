jQuery(document).ready(function($){
	$('input.color').wpColorPicker();
});