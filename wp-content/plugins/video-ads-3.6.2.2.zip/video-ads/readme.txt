<?php
// Silence is golden.
?>